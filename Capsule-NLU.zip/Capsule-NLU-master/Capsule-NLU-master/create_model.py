# -*- coding: utf-8 -*-
import tensorflow as tf

from capsule_masked import Capsule


# word_embedding_dim 词嵌入维度
# encoder_hidden_dim 编码器隐藏层维度
# intent_embedding_dim 意图嵌入维度
# slot_embedding_dim 槽位嵌入维度
# slot_decoder_hidden_dim 槽位解码器隐藏层维度
# intent_decoder_hidden_dim 槽位解码器隐藏层维度
# attention_hidden_dim 注意力隐藏层维度
# attention_output_dim 注意力输出维度

def self_attention(input_data, query_dim, key_dim, value_dim, hidden_dim, output_dim, dropout_rate):

    # linear transform
    linear_query = tf.layers.dense(input_data, hidden_dim, activation = None)
    linear_key = tf.layers.dense(input_data, hidden_dim, activation = None)
    linear_value = tf.layers.dense(input_data, output_dim, activation = None)

    # dot product
    outputs = tf.matmul(linear_query, tf.transpose(linear_key, [0,2,1]))  # outputs:[bsz, tstp, tstp] = [bsz, tstp, q_dim] * [bsz, k_dim, tstp]

    # scale
    outputs = outputs/(linear_key.get_shape().as_list()[-1]**0.5)
    score_tensor = tf.nn.softmax(outputs)
    outputs = tf.matmul(outputs, linear_value)

    # residual connection
    # outputs = outputs + queries

    return outputs

def lstm_decoder(input_data, input_dim, hidden_dim, output_dim, dropout_rate, embedding_dim=None, extra_dim=None,
                 is_Training):
    """
    :param input_data: 输入数据，即self_attentive向量
    :param input_dim:  输入数据的维度，就是lstm+self_attention
    :param hidden_dim: hidden dimension of iterative LSTM.
    :param output_dim: 解码器输出的维度，是意图的类别数或者槽位的类别数
    :param dropout_rate: dropout rate of network which is only useful for embedding
    :param embedding_dim: if it's not None, the input and output are relevant.
    :param extra_dim: if it's not None, the decoder receives information tensors.
    :return:

    这里他是一个句子一个句子进行处理的，考虑能不能使用batch进行
    """
    # if embedding_dim is not None, the output and input of this structure is relevant
    if embedding_dim is not None:
        embedding = tf.get_variable('embedding', [input_size, embed_dim],
                                    initializer = tf.contrib.layers.xavier_initializer())
    # make sure the input dimension of iterative LSTM.
    if extra_dim is not None and embedding_dim is not None:
        lstm_input_dim = input_dim + extra_dim + embedding_dim
    elif extra_dim is not None:
        lstm_input_dim = input_dim + extra_dim
    elif embedding_dim is not None:
        lstm_input_dim = input_dim + embedding_dim
    else:
        lstm_input_dim = input_dim


    # 对input_tensor进行处理，如果是意图则不需要拼接，如果是slot则需要进行拼接
    if extra_input is not None:
        input_tensor = tf.concat([input_data, extra_input], axis = -1)
    else:
        input_tensor = input_data

    output_tensor_list = []
    sent_start_pos = 0

    if embedding_dim is None or forced_input is not None:
        for sent_i in range(0, len(seq_lens)):
            sent_end_pos = sent_start_pos + seq_lens[sent_i]

            # Segment input hidden tensors.
            seg_hiddens = input_tensor[sent_start_pos:sent_end_pos, :]

            if embedding_dim is not None and forced_input is not None:
                if seq_lens[sent_i] > 1:
                    seg_forced_input = forced_input[sent_start_pos:sen_end_pos]
                    seg_forced_tensor =


def build_model(input_data, input_size, sequence_length, slot_size, intent_size, intent_dim, layer_size, embed_dim,
                num_rnn=1, isTraining=True, iter_slot=2, iter_intent=2, re_routing=True):
    cell_fw_list = tf.contrib.rnn.MultiRNNCell([tf.contrib.rnn.BasicLSTMCell(layer_size) for _ in range(num_rnn)])
    cell_bw_list = tf.contrib.rnn.MultiRNNCell([tf.contrib.rnn.BasicLSTMCell(layer_size) for _ in range(num_rnn)])

    if isTraining == True:
        cell_fw_list = tf.contrib.rnn.DropoutWrapper(cell_fw_list, input_keep_prob=0.8,
                                                     output_keep_prob=0.8)
        cell_bw_list = tf.contrib.rnn.DropoutWrapper(cell_bw_list, input_keep_prob=0.8,
                                                     output_keep_prob=0.8)

    embedding = tf.get_variable('embedding', [input_size, embed_dim],
                                initializer=tf.contrib.layers.xavier_initializer())
    inputs = tf.nn.embedding_lookup(embedding, input_data)
    query_dim = inputs.get_shape().as_list()[-1]


    with tf.variable_scope('self_attentive'):
        with tf.variable_scope('lstm_encoder'):
            H, _, _ = tf.contrib.rnn.stack_bidirectional_dynamic_rnn(
                [cell_fw_list],
                [cell_bw_list],
                inputs=inputs,
                sequence_length=sequence_length,
                dtype=tf.float32)

        with tf.variable_scope('self_attention'):
            attention_outputs = self_attention(inputs, query_dim, query_dim, query_dim, hidden_dim, output_dim, dropout_rate)
    self_attentive = tf.concat(H, attention_outputs, axis=-1)

    with tf.variable_scope('intent_decoder'):


    #     sc = Capsule(slot_size, layer_size, reuse=tf.AUTO_REUSE, iter_num=iter_slot, wrr_dim=(layer_size, intent_dim))
    #     slot_capsule, routing_weight, routing_logits = sc(H, sequence_length, re_routing=False)
    # with tf.variable_scope('slot_proj'):
    #     slot_p = tf.reshape(routing_logits, [-1, slot_size])
    # with tf.variable_scope('intent_capsule'):
    #     intent_capsule, intent_routing_weight, _ = Capsule(intent_size, intent_dim, reuse=tf.AUTO_REUSE,
    #                                                        iter_num=iter_intent)(slot_capsule, slot_size)
    # with tf.variable_scope('intent_proj'):
    #     intent = intent_capsule
    # outputs = [slot_p, intent, routing_weight, intent_routing_weight]
    # if re_routing:
    #     pred_intent_index_onehot = tf.one_hot(tf.argmax(tf.norm(intent_capsule, axis=-1), axis=-1), intent_size)
    #     pred_intent_index_onehot = tf.tile(tf.expand_dims(pred_intent_index_onehot, 2),
    #                                        [1, 1, tf.shape(intent_capsule)[2]])
    #     intent_capsule_max = tf.reduce_sum(tf.multiply(intent_capsule, tf.cast(pred_intent_index_onehot, tf.float32)),
    #                                        axis=1,
    #                                        keepdims=False)
    #     caps_ihat = tf.expand_dims(tf.expand_dims(intent_capsule_max, 1), 3)
    #     with tf.variable_scope('slot_capsule', reuse=True):
    #         slot_capsule_new, routing_weight_new, routing_logits_new = sc(H, sequence_length, caps_ihat=caps_ihat,
    #                                                                       re_routing=True)
    #     with tf.variable_scope('slot_proj', reuse=True):
    #         slot_p_new = tf.reshape(routing_logits_new, [-1, slot_size])
    #     outputs = [slot_p_new, intent, routing_weight_new, intent_routing_weight]
    return outputs
